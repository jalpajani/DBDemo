//
//  Constants.swift
//  DemoDB
//
//  Created by vivek versatile on 08/03/18.
//  Copyright © 2018 Jalpa Jani. All rights reserved.
//

import Foundation
import UIKit

let APPDELEGATE = UIApplication.shared.delegate as! AppDelegate

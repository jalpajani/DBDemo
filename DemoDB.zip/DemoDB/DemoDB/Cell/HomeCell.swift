//
//  HomeCell.swift
//  DemoDB
//
//  Created by vivek versatile on 08/03/18.
//  Copyright © 2018 Jalpa Jani. All rights reserved.
//

import UIKit

class HomeCell: UITableViewCell {

     @IBOutlet weak var lblName: UILabel!
     @IBOutlet weak var lblPhone: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

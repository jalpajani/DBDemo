//
//  ViewController.swift
//  DemoDB
//
//  Created by vivek versatile on 08/03/18.
//  Copyright © 2018 Jalpa Jani. All rights reserved.
//

import UIKit

struct ContactInfo {
    var ciD: Int!
    var name: String!
    var email: String!
    var phone: String!
}

class ViewController: UIViewController {

    
    @IBOutlet weak var tblList: UITableView!
    var contactData: [ContactInfo] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.setView()

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.fetchData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

//MARK: - @IBActions
extension ViewController
{
    @IBAction func btnClickedAdd(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "AddVC") as! AddVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.contactData.count > 0) {
            return self.contactData.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell:HomeCell? = tableView.dequeueReusableCell(withIdentifier: "HomeCell") as? HomeCell
        
        if (cell == nil) {
            let nib: NSArray = Bundle.main.loadNibNamed("HomeCell", owner: self, options: nil)! as NSArray
            cell = nib.object(at: 0) as? HomeCell
        }
        let data = self.contactData[indexPath.row]
        cell?.lblName.text = data.name
        cell?.lblPhone.text = data.phone
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "AddVC") as! AddVC
        vc.userContact = self.contactData[indexPath.row]
        vc.isEdit = true
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if (editingStyle == UITableViewCellEditingStyle.delete){
           self.deleteData(withID: self.contactData[indexPath.row].ciD)
            self.fetchData()
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return  true
    }
}


extension ViewController {
    
    func setView()
    {
         self.tblList.register(UINib(nibName: "HomeCell", bundle: nil), forCellReuseIdentifier: "HomeCell")
        
    }
    
    func fetchData()
    {
        let contactDB = FMDatabase(path: APPDELEGATE.databasePath as String)
        self.contactData.removeAll()
        if (contactDB.open()) {
            do {
                
                let query = "select * from CONTACTS"
                let results = try contactDB.executeQuery(query, values: nil)
                
                while results.next() {
                    let contacts = ContactInfo(ciD: Int(results.int(forColumn: "ID")), name: results.string(forColumn: "NAME"), email: results.string(forColumn: "EMAIL"), phone: results.string(forColumn: "PHONE"))
                
                    contactData.append(contacts)
                }
                self.tblList.reloadData()
                self.tblList.layoutIfNeeded()
            }
            catch {
                print(error.localizedDescription)
            }
             contactDB.close()
        } else {
            print("Error: \(contactDB.lastErrorMessage())")
        }
    }
    
    func deleteData(withID : Int) {
        
        let contactDB = FMDatabase(path: APPDELEGATE.databasePath as String)
        if (contactDB.open()) {
            let query = "delete from CONTACTS where ID=?"
            
            do {
                try contactDB.executeUpdate(query, values: [withID])
            }
            catch {
                print(error.localizedDescription)
            }
            contactDB.close()
        }
    }
    
}

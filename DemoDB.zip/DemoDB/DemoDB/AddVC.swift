//
//  AddVC.swift
//  DemoDB
//
//  Created by vivek versatile on 08/03/18.
//  Copyright © 2018 Jalpa Jani. All rights reserved.
//

import UIKit

class AddVC: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var imgUserProfile: UIImageView!
    
    var cameraController = UIImagePickerController()

    var userContact = ContactInfo()
    var isEdit : Bool  = false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.setView()
    }

}

extension AddVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    ///ImagePicker method
    func startCameraFromViewController(_ viewController: UIViewController,sourceType:UIImagePickerControllerSourceType, withDelegate delegate: UIImagePickerControllerDelegate & UINavigationControllerDelegate) -> Bool {
        
        if UIImagePickerController.isSourceTypeAvailable(sourceType) == false {
            return false
        }
        cameraController = UIImagePickerController()
        cameraController.sourceType = sourceType
        cameraController.allowsEditing = true
        cameraController.delegate = delegate
        
        present(cameraController, animated: true, completion: nil)
        return true
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true) {
            if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
                var selectedImage = UIImage()
                selectedImage = selectedImage.resizeImagewithSize(image: image, targetSize: CGSize(width: 200, height: 200))
                self.imgUserProfile.image = selectedImage
            }
        }
        
    }
    
    func openCamera()
    {
        let actionSheetController: UIAlertController = UIAlertController(title:nil, message: nil, preferredStyle: .actionSheet)
        
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            
        }
        cancelAction.setValue(UIColor.red, forKey: "titleTextColor")
        actionSheetController.addAction(cancelAction)
        
        let choosePictureAction: UIAlertAction = UIAlertAction(title: "Photo Library", style: .default) { action -> Void in
            
            _ = self.startCameraFromViewController(self, sourceType:.photoLibrary, withDelegate:self)
            
        }
        actionSheetController.addAction(choosePictureAction)
        self.present(actionSheetController, animated: true, completion: nil)
        
        let takePictureAction: UIAlertAction = UIAlertAction(title: "Choose From Camera Roll", style: .default) { action -> Void in
            _ = self.startCameraFromViewController(self, sourceType: .camera, withDelegate: self )
            
        }
        actionSheetController.addAction(takePictureAction)
    }
}

//MARK: - @IBActions
extension AddVC
{
    
    @IBAction func btnClickedCamera(_ sender: Any) {
        self.openCamera()
    }
    
    @IBAction func btnClickedBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnClickedAdd(_ sender: UIButton) {
        if isEdit {
            self.updateData()
            self.navigationController?.popViewController(animated: true)
        } else {
            self.addData()
            self.navigationController?.popViewController(animated: true)
        }
       
    }
}


extension AddVC {
    
    func addData()
    {
        let contactDB = FMDatabase(path: APPDELEGATE.databasePath as String)
        
        if (contactDB.open()) {
            
            let insertSQL = "INSERT INTO CONTACTS (name, email, phone, image) VALUES ('\(txtName.text!)', '\(txtEmail.text!)', '\(txtPhone.text!)', '\(UIImagePNGRepresentation(imgUserProfile.image!)!)')"
            
            let result = contactDB.executeUpdate(insertSQL,
                                                  withArgumentsIn: [])
            
            if !result {
                
                print("Error: \(contactDB.lastErrorMessage())")
            } else {
                print("Contact Added")
            }
        } else {
            print("Error: \(contactDB.lastErrorMessage())")
        }
    }
    
    func setView()
    {
        if isEdit {
            self.txtName.text = self.userContact.name
            self.txtEmail.text = self.userContact.email
            self.txtPhone.text = self.userContact.phone
        }
    }
    
    func updateData()
    {
        let contactDB = FMDatabase(path: APPDELEGATE.databasePath as String)
        
        if (contactDB.open()) {
            let query = "update CONTACTS set name=?, email=?, phone=? where ID=?"
            
            do {
                try contactDB.executeUpdate(query, values: [txtName.text!, txtEmail.text!, txtPhone.text!, self.userContact.ciD])
            }
            catch {
                print(error.localizedDescription)
            }
            
            contactDB.close()
        }
    }
}
